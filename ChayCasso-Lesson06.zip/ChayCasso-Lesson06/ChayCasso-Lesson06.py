#-------------------------------------------------#
# Title: Working with Dictionaries
# Dev:   RRoot
# Date:  July 16, 2012
# ChangeLog: (Who, When, What)
#   RRoot, 11/02/2016, Created starting template
#   Chay Casso, 10/28/2017, Added code to complete assignment 5
#   Chay Casso, 11/5/2017, Added code to complete assignment 6
#https://www.tutorialspoint.com/python/python_dictionary.htm
#-------------------------------------------------#

# -- Data --#
# declare variables and constants
# objFile = An object that represents a file
# objFileName = The name of said file
# strData = A row of text data from the file
# dicRow = A row of data separated into elements of a dictionary {Task,Priority}
# lstTable = A dictionary that acts as a 'table' of rows
# strMenu = A menu of user options
# strChoice = Capture the user option selection
# strKey = Extracted key from a dictionary
# strValue = Extracted value from a dictionary

objFileName = "ToDo.txt"
strData = ""
dicRow = {}
lstTable = []

class ToDoProcessing():
    #-- Input/Output --#
    # User can see a Menu (Step 2)
    @staticmethod
    def GenerateMenu():
        """Prints the menu then asks for an input in response."""
        strChoice="0"
        print("""
            Menu of Options
            1) Show current data
            2) Add a new item
            3) Remove an existing item
            4) Save data to file
            5) Exit Program
            """)
        while int(strChoice) not in range(1, 6):
            strChoice = str(input("Which option would you like to perform? [1 to 5] - "))
        return(strChoice)
    #end GenerateMenu

    # User can see data (Step 3)
    @staticmethod
    def DisplayData(lstTable):
        """Prints all rows of lstTable."""
        for row in lstTable:
            print(str(row))
    #end DisplayData

    # User can insert or delete data(Step 4 and 5)
    @staticmethod
    def InsertDeleteData(lstTable, boolAddData):
        """Depending on boolAddData, either inserts or deletes data from lstTable."""
        if (boolAddData == True): #User wants to insert data
            strChoice = input("Which task do you want to add? - ")
            for row in lstTable: #Scans table to avoid duplicates
                for strKey, strValue in row.items():
                    if strChoice == strKey:
                        print("Task already exists.")
                        return(lstTable)
            strPriority = input("What is your task's priority? (low/medium/high) - ")
            dicRow = {strChoice.strip(): strPriority.strip()}
            lstTable.append(dicRow)

        else: #User wants to delete data
            strChoice = input("Which task do you want to delete? - ")
            for row in lstTable: #Looking for a match for the task
                for strKey, strValue in row.items():
                    if strChoice == strKey: #Match found
                        lstTable.remove(row)
                        boolFlag = False #Saying that a match was indeed found.
                        break
                    else:
                        boolFlag = True #A match was not found.
            if (boolFlag == True): print ("The task was not found.")

        return(lstTable)
    #end InsertDeleteData


    # User can save to file (Step 6)
    @staticmethod
    def SaveFile(lstTable, objFileName):
        """Takes lstTable, opens objFileName in write mode, writes out lstTable to objFileName by lines."""
        objFile = open(objFileName, "w")
        for row in lstTable: #Scans lstTable for rows
            for strKey, strValue in row.items():
                objFile.write(strKey + "," + strValue + "\n") #Prints to the file in strKey,strValue format.
        print("Data has been saved.")
        objFile.close()
    #end SaveFile


#-- Processing --#
# Step 1
# When the program starts, load the any data you have
# in a text file called ToDo.txt into a python Dictionary.

# Note: the format of the file is comma delimited, each row is read as Key,Value.
objFile = open(objFileName, "r")
for Row in objFile:
    strData = Row #spits out row into a String
    dicRow = {strData.split(',')[0].strip(): strData.split(',')[1].strip()} #Splits and formats the string.
    lstTable.append(dicRow)
objFile.close()

# Step 2
# Display a menu of choices to the user
while(True):
    strChoice = ToDoProcessing.GenerateMenu()
    print()  #adding a new line

    # Step 3 -Show the current items in the table
    if (strChoice.strip() == '1'):
        ToDoProcessing.DisplayData(lstTable)
        continue
    # Step 4 - Add a new item to the list/Table
    elif(strChoice.strip() == '2'):
        lstTable = ToDoProcessing.InsertDeleteData(lstTable, True)
        continue
    # Step 5 - Remove a new item to the list/Table
    elif(strChoice.strip() == '3'):
        lstTable = ToDoProcessing.InsertDeleteData(lstTable, False)
        continue
    # Step 6 - Save tasks to the ToDo.txt file
    elif(strChoice.strip() == '4'):
        ToDoProcessing.SaveFile(lstTable, objFileName)
        continue
    elif (strChoice.strip() == '5'):
        break #and Exit the program
    else:
        print("Please select a value from 1 to 5.")

